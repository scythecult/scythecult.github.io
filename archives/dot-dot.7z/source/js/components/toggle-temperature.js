import { elements, CLASSES } from "./utils.js";

const onCheckboxClick = () => {
  toggleCheckedAttribute();
  toggleActiveClass();
};

const onCheckboxKeydown = (evt) => {
  if (evt.key === " ") {
    evt.preventDefault();
    toggleCheckedAttribute();
    toggleActiveClass();
  }
};

const toggleActiveClass = () => {
  elements.tempContainer.classList.toggle(CLASSES.ACTIVE);
};

const toggleCheckedAttribute = () => {
  if (elements.tempCheckbox.hasAttribute("checked")) {
    elements.tempCheckbox.removeAttribute("checked");
  } else {
    elements.tempCheckbox.setAttribute("checked", "");
  }
};

export { onCheckboxClick, onCheckboxKeydown };
