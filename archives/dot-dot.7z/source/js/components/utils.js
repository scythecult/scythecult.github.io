const elements = {
  tempContainer: document.querySelector(".cargo__temp"),
  tempLabel: document.querySelector(".cargo__check-label"),
  tempCheckbox: document.querySelector(".cargo__check"),
};

const CLASSES = {
  ACTIVE: "temp-active",
};

export { elements, CLASSES };
