import { elements } from "./components/utils.js";
import {
  onCheckboxClick,
  onCheckboxKeydown,
} from "./components/toggle-temperature.js";

elements.tempLabel.addEventListener("click", onCheckboxClick);
elements.tempContainer.addEventListener("keydown", onCheckboxKeydown);
