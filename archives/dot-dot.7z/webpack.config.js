const webpackConfig = {
  mode: "development",
  output: {
    filename: "bundle.js",
  },
  devtool: "source-map",
  module: {
    rules: [
      {
        test: /\.(js)$/,
        exclude: /(node_modules)/,
        loader: "babel-loader",
        query: {
          presets: ["@babel/preset-env"],
          targets: {
            browsers: ["last 2 versions", "safari >= 7"],
          },
        },
      },
    ],
  },
};

export { webpackConfig };
