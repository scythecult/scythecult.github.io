const FOLDERS = {
  BUILD: "build",
  SOURCE: "source",
};

const PATHS = {
  dest: {
    html: `${FOLDERS.BUILD}/`,
    css: `${FOLDERS.BUILD}/css/`,
    js: `${FOLDERS.BUILD}/js/`,
    img: `${FOLDERS.BUILD}/img/`,
    video: `${FOLDERS.BUILD}/video/`,
    fonts: `${FOLDERS.BUILD}/fonts/`,
  },

  source: {
    html: [`${FOLDERS.SOURCE}/*.html`, `!${FOLDERS.SOURCE}/_*.html`],
    css: `${FOLDERS.SOURCE}/sass/common/style.scss`,
    js: `${FOLDERS.SOURCE}/js/**/*.js`,
    img: [
      `${FOLDERS.SOURCE}/img/**/*.*`,
      `!${FOLDERS.SOURCE}/img/**/icon-*.svg`,
    ],
    video: `${FOLDERS.SOURCE}/video/**/*.{mp4,ogv,webm}`,
    fonts: `${FOLDERS.SOURCE}/fonts/**/*.{woff2,woff,ttf,otf}`,
  },

  watch: {
    html: `${FOLDERS.SOURCE}/**/*.html`,
    css: `${FOLDERS.SOURCE}/sass/**/*.scss`,
    js: `${FOLDERS.SOURCE}/js/**/*.js`,
    img: `${FOLDERS.SOURCE}/img/**/*.{jpg,png,svg,ico}`,
  },

  clean: `./${FOLDERS.BUILD}/`,
};

export { FOLDERS, PATHS };
