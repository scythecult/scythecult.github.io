// * GOBAL PATHS
import { FOLDERS, PATHS } from "./gulp.paths.js";
// * PACKAGES
import gulp from "gulp";
import del from "del";
import rename from "gulp-rename";
import plumber from "gulp-plumber";
import server from "browser-sync";
import ttf2woff from "ttf2woff";
import ttf2woff2 from "ttf2woff2";
import HTMLmin from "gulp-htmlmin";
import { htmlValidator } from "gulp-w3c-html-validator";
import sass from "gulp-sass";
import gcmq from "gulp-group-css-media-queries";
import cleanCss from "gulp-clean-css";
import autoPrefixer from "gulp-autoprefixer";
import sourcemap from "gulp-sourcemaps";
import webpack from "webpack";
import webpackStream from "webpack-stream";
import { webpackConfig } from "./webpack.config.js";
const { src, dest } = gulp;
server.create();

const createServer = () => {
  server.init({
    server: `${FOLDERS.BUILD}/`,
    notify: false,
    open: true,
    cors: true,
    ui: false,
  });
};

const html = () => {
  return src(PATHS.source.html)
    .pipe(plumber())
    .pipe(htmlValidator.analyzer())
    .pipe(htmlValidator.reporter())
    .pipe(dest(PATHS.dest.html))
    .pipe(
      HTMLmin({
        removeComments: true,
        collapseWhitespace: true,
      })
    )
    .pipe(
      rename({
        extname: ".min.html",
      })
    )
    .pipe(dest(PATHS.dest.html))
    .pipe(server.stream());
};

const css = () => {
  return src(PATHS.source.css)
    .pipe(plumber())
    .pipe(sourcemap.init())
    .pipe(sass().on("error", sass.logError))
    .pipe(gcmq())
    .pipe(
      autoPrefixer({
        cascade: true,
      })
    )
    .pipe(dest(PATHS.dest.css))
    .pipe(cleanCss())
    .pipe(
      rename({
        extname: ".min.css",
      })
    )
    .pipe(sourcemap.write("."))
    .pipe(dest(PATHS.dest.css))
    .pipe(server.stream());
};

const getJs = () => {
  return src(PATHS.source.js)
    .pipe(plumber())
    .pipe(webpackStream(webpackConfig), webpack)
    .pipe(dest(PATHS.dest.js))
    .pipe(server.stream());
};

const copyFiles = () => {
  return src([PATHS.source.fonts, ...PATHS.source.img, PATHS.source.video], {
    base: FOLDERS.SOURCE,
  }).pipe(dest(FOLDERS.BUILD));
};

const refresh = (done) => {
  server.reload();
  done();
};

const watchFiles = () => {
  gulp.watch([PATHS.watch.html], gulp.series(html, refresh));
  gulp.watch([PATHS.watch.css], css);
  gulp.watch([PATHS.watch.js], getJs);
  gulp.watch([PATHS.watch.img]);
};

const clean = () => {
  return del(PATHS.clean);
};

const getFonts = () => {
  src(PATHS.source.fonts)
    .pipe(ttf2woff())
    .pipe(dest(`${FOLDERS.SOURCE}/fonts/`));
  return src(PATHS.source.fonts)
    .pipe(ttf2woff2())
    .pipe(dest(`${FOLDERS.SOURCE}/fonts/`));
};

const build = gulp.series(clean, copyFiles, gulp.series(html, css, getJs));

const watch = gulp.series(build, gulp.parallel(watchFiles, createServer));

export { getJs, getFonts, build, watch as default };
