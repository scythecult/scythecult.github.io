import { renderCards } from "./components/house-card";
import { filter } from "./components/filter";

const URL = "https://603e38c548171b0017b2ecf7.mockapi.io/homes";
const houseList = document.querySelector(".latest-devs__houses");

const handleResponse = (response) => {
  if (response.ok) {
    return response.json();
  }
};

const response = fetch(URL, {
  method: "GET",
  credentials: "same-origin",
});

response
  .then(handleResponse)
  .then((houseData) => {
    renderCards(houseData, houseList);
  })
  .then(() => filter(houseList));
