const Pictures = ["img/house-1", "img/house-2", "img/house-3"];
const Status = {
  IndependentLiving: {
    className: "house-card__lable--ind",
    text: "Independent Living",
  },
  SupportAvailable: {
    className: "house-card__lable--sup",
    text: "Restaurant & Support available",
  },
};

const getRandomElement = () => {
  let rand = 0 - 0.5 + Math.random() * (Pictures.length - 1 - 0 + 1);
  return Math.abs(Math.round(rand));
};

const createHouseCardMarkup = (houseData) => {
  const { id, title, address, type, price } = houseData;
  const picture = Pictures[getRandomElement()];
  const status = Status[type];

  return `
  <li class="latest-devs__card house-card" data-title="${title.toLowerCase()}">
  <a class="house-card__img-link" href="/details/${id}">
  <picture>
    <source type="image/webp" srcset="${picture}.webp 1x, ${picture}@2x.webp 2x">
    <img class="house-card__img" src="${picture}.jpg" srcset="${picture}@2x.jpg 2x" width="377" height="227" alt="Image of ${title}">
  </picture>
  </a>
  <p class="house-card__label ${status.className}">${status.text}</p>
  <div class="house-card__desc page-text">
    <h3 class="house-card__title page-subtitle">${title}</h3>
    <address class="house-card__address">${address}</address>
    <p class="house-card__sale-info">New Properties for Sale from <b class="house-card__price">£${price}</b>
    </p>
    <p class="house-card__avail">Shared Ownership Available</p>
  </div>
</li>
  `;
};

const generateCardElements = (cardData, template) => {
  return cardData.map((it) => template(it));
};

const renderCards = (houseData, container) => {
  const cards = generateCardElements(houseData, createHouseCardMarkup).join(
    "\n"
  );

  container.insertAdjacentHTML("beforeend", cards);
};

export { renderCards };
