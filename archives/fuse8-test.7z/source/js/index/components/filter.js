const filter = (targetContainer) => {
  const form = document.querySelector(".filter-form");
  const targetElements = targetContainer.children;

  const findElement = (searchTerm) => {
    if (searchTerm.length >= 3 || searchTerm.length === 0) {
      for (const target of targetElements) {
        if (target.dataset.title.includes(searchTerm)) {
          target.classList.remove("latest-devs__card--hidden");
        } else {
          target.classList.add("latest-devs__card--hidden");
        }
      }
    }
  };

  const onFilterKeyup = (evt) => {
    const searchTerm = evt.target.value.toLowerCase().trim();

    findElement(searchTerm, targetElements);
  };

  form.addEventListener("keyup", onFilterKeyup);
};

export { filter };
