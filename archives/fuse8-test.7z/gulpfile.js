// * GOBAL PATHS
import { FOLDERS, PATHS } from "./gulp.paths.js";
// * PACKAGES
import gulp from "gulp";
import del from "del";
import rename from "gulp-rename";
import plumber from "gulp-plumber";
import server from "browser-sync";
import HTMLmin from "gulp-htmlmin";
import { htmlValidator } from "gulp-w3c-html-validator";
import less from "gulp-less";
import gcmq from "gulp-group-css-media-queries";
import cleanCss from "gulp-clean-css";
import autoPrefixer from "gulp-autoprefixer";
import sourcemap from "gulp-sourcemaps";
import imagemin from "gulp-imagemin";
import webp from "gulp-webp";
import svgSprite from "gulp-svg-sprite";
import ttf2woff from "gulp-ttf2woff";
import ttf2woff2 from "gulp-ttf2woff2";
import webpack from "webpack";
import webpackStream from "webpack-stream";
import { webpackConfig } from "./webpack.config.js";
const { src, dest } = gulp;
server.create();

const createServer = () => {
  server.init({
    server: `${FOLDERS.BUILD}/`,
    notify: false,
    open: true,
    cors: true,
    ui: false,
  });
};

const html = () => {
  return src(PATHS.source.html)
    .pipe(plumber())
    .pipe(htmlValidator.analyzer())
    .pipe(htmlValidator.reporter())
    .pipe(dest(PATHS.dest.html))
    .pipe(
      HTMLmin({
        removeComments: true,
        collapseWhitespace: true,
      })
    )
    .pipe(
      rename({
        extname: ".min.html",
      })
    )
    .pipe(dest(PATHS.dest.html))
    .pipe(server.stream());
};

const css = () => {
  return src(PATHS.source.css)
    .pipe(plumber())
    .pipe(sourcemap.init())
    .pipe(less())
    .pipe(gcmq())
    .pipe(
      autoPrefixer({
        cascade: true,
      })
    )
    .pipe(dest(PATHS.dest.css))
    .pipe(cleanCss())
    .pipe(
      rename({
        extname: ".min.css",
      })
    )
    .pipe(sourcemap.write("."))
    .pipe(dest(PATHS.dest.css))
    .pipe(server.stream());
};

const getJs = () => {
  return src(PATHS.source.js)
    .pipe(plumber())
    .pipe(webpackStream(webpackConfig), webpack)
    .pipe(dest(PATHS.dest.js))
    .pipe(server.stream());
};

const copyFiles = () => {
  return src([PATHS.source.fonts, ...PATHS.source.img, PATHS.source.video], {
    base: FOLDERS.SOURCE,
  }).pipe(dest(FOLDERS.BUILD));
};

const refresh = (done) => {
  server.reload();
  done();
};

const watchFiles = () => {
  gulp.watch([PATHS.watch.html], gulp.series(html, refresh));
  gulp.watch([PATHS.watch.css], css);
  gulp.watch([PATHS.watch.js], getJs);
  gulp.watch([PATHS.watch.img]);
};

const clean = () => {
  return del(PATHS.clean);
};

const getImages = () => {
  return src(`${FOLDERS.SOURCE}/img/**/*.{jpg,png,svg,ico}`)
    .pipe(
      imagemin([
        imagemin.gifsicle({ interlaced: true }),
        imagemin.mozjpeg({ quality: 75, progressive: true }),
        imagemin.optipng({ optimizationLevel: 3 }),
        // imagemin.svgo({
        //   plugins: [
        // { removeViewBox: false },
        // { removeAttrs: { attrs: "(stroke|fill)" } },
        //   ],
        // }),
      ])
    )
    .pipe(dest(PATHS.dest.img))
    .pipe(server.stream());
};

const getSprite = () => {
  return gulp
    .src([`${FOLDERS.SOURCE}/img/icon-*.svg`])
    .pipe(
      imagemin([
        imagemin.svgo({
          plugins: [
            { removeViewBox: false },
            { removeAttrs: { attrs: "(stroke|fill)" } },
          ],
        }),
      ])
    )
    .pipe(
      svgSprite({
        mode: {
          stack: {
            sprite: "../icons/sprite.svg",
          },
        },
      })
    )

    .pipe(dest(PATHS.dest.img));
};

const getWebp = () => {
  return src([`${FOLDERS.SOURCE}/img/**/*.{png,jpg}`])
    .pipe(
      webp({
        quality: 85,
      })
    )
    .pipe(dest(PATHS.dest.img));
};

const getFonts = () => {
  src(PATHS.source.fonts)
    .pipe(ttf2woff())
    .pipe(dest(`${FOLDERS.SOURCE}/fonts/`));
  return src(PATHS.source.fonts)
    .pipe(ttf2woff2())
    .pipe(dest(`${FOLDERS.SOURCE}/fonts/`));
};

const build = gulp.series(
  clean,
  copyFiles,
  gulp.series(html, css, getJs, getImages, getWebp, getSprite)
);

const watch = gulp.series(build, gulp.parallel(watchFiles, createServer));

export {
  getJs,
  getImages,
  getSprite,
  getWebp,
  getFonts,
  build,
  watch as default,
};
